package uk.ac.soton.ecs.bm6g14.ch6;

public class Tutorial6_1_2 {
/*
 * According to the Apache documentation it supports a large variety of files to build the dataset from.
 * These include FTP and HTTP, ZIP files as we know along with BZIP2, GZIP and Tar.
 */
}
