package uk.ac.soton.ecs.bm6g14;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigourous Test :-)
     */
	@Test
    public void testApp() {
        assertTrue( true );
    }
}
